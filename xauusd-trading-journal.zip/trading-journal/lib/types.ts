export type Outcome = 'full_tp' | 'break_even' | 'stop_loss' | 'manual_close';
export type Direction = 'BUY' | 'SELL';

export type Trade = {
  id: string;
  trade_date: string;
  instrument: string;
  trade_number: number;
  direction: Direction;
  entry: number;
  stop_loss: number;
  take_profit: number;
  outcome: Outcome;
  pips: number;
  session: string | null;
  strategy: string | null;
  notes: string | null;
  image_url: string | null;
  image_path: string | null;
  created_at?: string;
};

export const seedTrades: Trade[] = [
  { id:'seed-2801', trade_date:'2026-09-28', instrument:'XAUUSD', trade_number:1, direction:'SELL', entry:4205, stop_loss:4210, take_profit:4163, outcome:'full_tp', pips:430, session:'London', strategy:null, notes:'Full TP. Reported +430 pips.', image_url:'/seed-images/2026-09-28-trade-01-sell.png', image_path:null },
  { id:'seed-2802', trade_date:'2026-09-28', instrument:'XAUUSD', trade_number:2, direction:'SELL', entry:4147, stop_loss:4152, take_profit:4137, outcome:'break_even', pips:0, session:'London', strategy:null, notes:'Reached +60 pips before break-even; not booked as profit.', image_url:'/seed-images/2026-09-28-trade-02-sell.png', image_path:null },
  { id:'seed-2803', trade_date:'2026-09-28', instrument:'XAUUSD', trade_number:3, direction:'SELL', entry:4163, stop_loss:4168, take_profit:4153, outcome:'full_tp', pips:100, session:'London', strategy:null, notes:'Full target hit per chart annotation.', image_url:'/seed-images/2026-09-28-trade-03-sell.png', image_path:null },
  { id:'seed-2804', trade_date:'2026-09-28', instrument:'XAUUSD', trade_number:4, direction:'BUY', entry:4152, stop_loss:4143, take_profit:4158, outcome:'break_even', pips:0, session:'London', strategy:null, notes:'Corrected journal state: break-even, not full TP. Written entry retained.', image_url:'/seed-images/2026-09-28-trade-04-buy.png', image_path:null },
  { id:'seed-2901', trade_date:'2026-09-29', instrument:'XAUUSD', trade_number:1, direction:'SELL', entry:4141, stop_loss:4146, take_profit:4131, outcome:'stop_loss', pips:-50, session:'London', strategy:null, notes:'SL hit. Sideways price action during London session.', image_url:'/seed-images/2026-09-29-trade-01-sell.png', image_path:null },
  { id:'seed-3001', trade_date:'2026-09-30', instrument:'XAUUSD', trade_number:1, direction:'BUY', entry:4174, stop_loss:4169, take_profit:4184, outcome:'full_tp', pips:100, session:'London', strategy:null, notes:'Full TP +100 pips.', image_url:'/seed-images/2026-09-30-trade-01-buy.png', image_path:null },
];
