import type { Outcome, Trade } from './types';

export function formatPrice(value: number) {
  return value.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 });
}

export function formatDate(value: string) {
  return new Intl.DateTimeFormat('en-GB', { day:'2-digit', month:'short', year:'numeric' }).format(new Date(`${value}T00:00:00`));
}

export function outcomeLabel(outcome: Outcome) {
  return { full_tp:'Full TP', break_even:'Break-even', stop_loss:'Stop loss', manual_close:'Manual close' }[outcome];
}

export function outcomeClass(outcome: Outcome) {
  return `outcome outcome-${outcome.replace('_','-')}`;
}

export function stats(trades: Trade[]) {
  const total = trades.reduce((s,t)=>s+t.pips,0);
  return { count: trades.length, pips: total, fullTp: trades.filter(t=>t.outcome==='full_tp').length, be: trades.filter(t=>t.outcome==='break_even').length, sl: trades.filter(t=>t.outcome==='stop_loss').length };
}
