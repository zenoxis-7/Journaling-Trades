# XAUUSD Trade Journal

Minimal personal trading journal built for Vercel + Supabase.

## Features
- Minimal dark dashboard inspired by the supplied screenshots.
- Six supplied trades are seeded into the initial journal.
- Add trades with BUY/SELL, entry, SL, TP, outcome, pips, session, strategy, notes and chart image.
- Supabase Storage uploads for new chart images.
- Supabase Auth + RLS for private data.
- Search and filters.
- Browser demo mode when Supabase env vars are absent.

## 1. Install

```bash
npm install
npm run dev
```

## 2. Supabase

Create a Supabase project, then run `supabase/schema.sql` in the SQL Editor.

Create `.env.local` from `.env.example`:

```env
NEXT_PUBLIC_SUPABASE_URL=your-project-url
NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY=your-publishable-key
```

The current Supabase Next.js SSR pattern uses `@supabase/ssr` with cookie-based sessions. See the official docs linked in the handoff message.

## 3. Auth email confirmation

If Supabase email confirmation is enabled, configure the confirmation email to redirect through:

`/auth/confirm?token_hash={{ .TokenHash }}&type=signup`

Also add your Vercel domain to Supabase Auth URL configuration.

## 4. Deploy

Push this folder to GitHub and import it into Vercel. Add the two environment variables in Vercel, then deploy.

## Seed images

The six chart crops from the supplied screenshots are stored under `public/seed-images`. They are intentionally local seed assets so the dashboard renders immediately. New uploaded charts go to the `trade-charts` Supabase bucket.
