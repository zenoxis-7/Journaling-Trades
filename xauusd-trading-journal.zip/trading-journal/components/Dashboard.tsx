'use client';
import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { createClient } from '@/lib/supabase/client';
import { seedTrades, type Trade, type Outcome } from '@/lib/types';
import { stats } from '@/lib/utils';
import TradeCard from './TradeCard';
import TradeForm from './TradeForm';

const DEMO_KEY='xauusd-journal-demo-trades';
const supabaseEnabled=Boolean(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY);

export default function Dashboard(){
  const [trades,setTrades]=useState<Trade[]>([]); const [loaded,setLoaded]=useState(false); const [showForm,setShowForm]=useState(false); const [query,setQuery]=useState(''); const [outcome,setOutcome]=useState<'all'|Outcome>('all'); const [direction,setDirection]=useState<'all'|'BUY'|'SELL'>('all'); const [dateRange,setDateRange]=useState('all');
  const load=async()=>{
    if(!supabaseEnabled){const raw=localStorage.getItem(DEMO_KEY); setTrades(raw?JSON.parse(raw):seedTrades); setLoaded(true); return;}
    const supabase=createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user){setLoaded(true);return;}
    let {data,error}=await supabase.from('trades').select('*').order('trade_date',{ascending:false}).order('trade_number',{ascending:true});
    if(error){console.error(error);setTrades([]);setLoaded(true);return;}
    if(!data?.length){const rows=seedTrades.map(({id,...t})=>({...t,user_id:user.id})); const ins=await supabase.from('trades').insert(rows).select(); if(!ins.error) data=ins.data;}
    setTrades((data??[]) as Trade[]); setLoaded(true);
  };
  useEffect(()=>{load()},[]);
  const filtered=useMemo(()=>trades.filter(t=>(outcome==='all'||t.outcome===outcome)&&(direction==='all'||t.direction===direction)&&(dateRange==='all'||t.trade_date>=dateRange)&&`${t.instrument} ${t.direction} ${t.notes??''} ${t.strategy??''}`.toLowerCase().includes(query.toLowerCase())),[trades,outcome,direction,dateRange,query]);
  const s=stats(filtered);
  const save=async(input:Omit<Trade,'id'>,file:File|null)=>{
    if(!supabaseEnabled){const t={...input,id:`local-${crypto.randomUUID()}`}; const next=[t,...trades]; localStorage.setItem(DEMO_KEY,JSON.stringify(next)); setTrades(next);setShowForm(false);return;}
    const supabase=createClient(); const {data:{user}}=await supabase.auth.getUser(); if(!user) throw new Error('Not signed in');
    let image_url=input.image_url,image_path=input.image_path;
    if(file){const path=`${user.id}/${crypto.randomUUID()}-${file.name.replace(/[^a-zA-Z0-9._-]/g,'-')}`; const up=await supabase.storage.from('trade-charts').upload(path,file,{contentType:file.type,upsert:false}); if(up.error)throw up.error; image_path=path; image_url=supabase.storage.from('trade-charts').getPublicUrl(path).data.publicUrl;}
    const ins=await supabase.from('trades').insert({...input,user_id:user.id,image_url,image_path}).select().single(); if(ins.error)throw ins.error; setTrades([ins.data as Trade,...trades]);setShowForm(false);
  };
  const remove=async(id:string)=>{if(!confirm('Delete this trade?'))return; const t=trades.find(x=>x.id===id); if(supabaseEnabled){const supabase=createClient(); if(t?.image_path)await supabase.storage.from('trade-charts').remove([t.image_path]); await supabase.from('trades').delete().eq('id',id);} const next=trades.filter(x=>x.id!==id); if(!supabaseEnabled)localStorage.setItem(DEMO_KEY,JSON.stringify(next)); setTrades(next)};
  const signOut=async()=>{if(supabaseEnabled)await createClient().auth.signOut(); location.href='/auth/login'};
  if(!loaded)return <main className="shell"><div className="empty">Loading journal…</div></main>;
  return <main className="shell">
    <header className="topbar"><div className="brand"><div className="brand-mark">X</div><div><div className="eyebrow">Gold / XAUUSD</div><div className="title">Trade Journal</div></div></div><div className="top-actions"><Link className="btn" href="/">Dashboard</Link>{supabaseEnabled?<button className="btn" onClick={signOut}>Sign out</button>:<span className="btn" style={{color:'#999'}}>Demo mode</span>}</div></header>
    {!supabaseEnabled&&<div className="demo-note">Demo mode is active because Supabase environment variables are not configured. Data is stored in this browser. Add the variables to switch to Supabase persistence.</div>}
    <section className="hero"><div><div className="eyebrow">Journal overview</div><h1>XAUUSD</h1><p>Minimal trade review, without dashboard clutter.</p></div><button className="btn primary" onClick={()=>setShowForm(v=>!v)}>{showForm?'Close':'＋ Add trade'}</button></section>
    {showForm&&<section className="card form-shell" style={{padding:20,marginBottom:20}}><div className="section-head"><h2>New trade</h2><span>Screenshot + execution data</span></div><TradeForm onSave={save}/></section>}
    <div className="filters"><input className="search" placeholder="Search trades…" value={query} onChange={e=>setQuery(e.target.value)}/><select className="select" value={direction} onChange={e=>setDirection(e.target.value as typeof direction)}><option value="all">All directions</option><option value="BUY">BUY</option><option value="SELL">SELL</option></select><select className="select" value={outcome} onChange={e=>setOutcome(e.target.value as typeof outcome)}><option value="all">All outcomes</option><option value="full_tp">Full TP</option><option value="break_even">Break-even</option><option value="stop_loss">Stop loss</option><option value="manual_close">Manual close</option></select><select className="select" value={dateRange} onChange={e=>setDateRange(e.target.value)}><option value="all">All dates</option><option value="2026-10-01">From Oct 1</option><option value="2026-09-01">From Sep 1</option></select></div>
    <section className="stats"><div className="stat"><div className="stat-label">Trades</div><div className="stat-value">{s.count}</div></div><div className="stat"><div className="stat-label">Recorded pips</div><div className={`stat-value ${s.pips>0?'positive':s.pips<0?'negative':''}`}>{s.pips>0?'+':''}{s.pips}</div></div><div className="stat"><div className="stat-label">Full TP</div><div className="stat-value">{s.fullTp}</div></div><div className="stat"><div className="stat-label">Break-even</div><div className="stat-value">{s.be}</div></div><div className="stat"><div className="stat-label">Stop loss</div><div className="stat-value">{s.sl}</div></div></section>
    <div className="section-head"><h2>Trades & charts</h2><span>{filtered.length} shown</span></div>
    {filtered.length?<div className="grid">{filtered.map(t=><TradeCard key={t.id} trade={t} onDelete={remove}/>)}</div>:<div className="empty">No trades match the current filters.</div>}
    <div className="footer">Initial journal seeded with the six trades from your supplied screenshots. New screenshots are stored in Supabase Storage when connected.</div>
  </main>
}
