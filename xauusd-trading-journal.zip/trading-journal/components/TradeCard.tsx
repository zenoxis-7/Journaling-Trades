'use client';
import type { Trade } from '@/lib/types';
import { formatDate, formatPrice, outcomeClass, outcomeLabel } from '@/lib/utils';

export default function TradeCard({ trade, onDelete }: { trade: Trade; onDelete?: (id: string) => void }) {
  const resultClass = trade.pips > 0 ? 'positive' : trade.pips < 0 ? 'negative' : '';
  return <article className="card">
    <div className="card-head">
      <div className="card-title">{formatDate(trade.trade_date)} · Trade {String(trade.trade_number).padStart(2,'0')} · {trade.direction}</div>
      <div className={outcomeClass(trade.outcome)}>{outcomeLabel(trade.outcome)}</div>
    </div>
    {trade.image_url ? <img className="chart" src={trade.image_url} alt={`${trade.instrument} ${trade.direction} trade chart`} /> : <div className="chart" />}
    <div className="card-body">
      <div className="numbers">
        <div><div className="num-label">Entry</div><div className="num">{formatPrice(trade.entry)}</div></div>
        <div><div className="num-label">Stop loss</div><div className="num">{formatPrice(trade.stop_loss)}</div></div>
        <div><div className="num-label">Take profit</div><div className="num">{formatPrice(trade.take_profit)}</div></div>
      </div>
      <div className="card-foot">
        <div><div className={`result ${resultClass}`}>{trade.pips > 0 ? '+' : ''}{trade.pips} pips</div><div className="meta">{trade.session ?? 'Session not set'}{trade.strategy ? ` · ${trade.strategy}` : ''}</div></div>
        {onDelete && <button className="btn" onClick={() => onDelete(trade.id)}>Delete</button>}
      </div>
      {trade.notes && <div className="meta" style={{marginTop:12,lineHeight:1.5}}>{trade.notes}</div>}
    </div>
  </article>;
}
