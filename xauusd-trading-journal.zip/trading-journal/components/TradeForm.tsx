'use client';
import { useState } from 'react';
import type { Direction, Outcome, Trade } from '@/lib/types';

export default function TradeForm({ onSave }: { onSave: (trade: Omit<Trade,'id'>, file: File | null) => Promise<void> }) {
  const [date,setDate]=useState(new Date().toISOString().slice(0,10));
  const [instrument,setInstrument]=useState('XAUUSD'); const [number,setNumber]=useState('1'); const [direction,setDirection]=useState<Direction>('BUY');
  const [entry,setEntry]=useState(''); const [sl,setSl]=useState(''); const [tp,setTp]=useState(''); const [outcome,setOutcome]=useState<Outcome>('full_tp');
  const [pips,setPips]=useState(''); const [session,setSession]=useState('London'); const [strategy,setStrategy]=useState(''); const [notes,setNotes]=useState(''); const [file,setFile]=useState<File|null>(null); const [busy,setBusy]=useState(false);
  const submit=async(e:React.FormEvent)=>{e.preventDefault(); if(!entry||!sl||!tp||!pips)return; setBusy(true); try{await onSave({trade_date:date,instrument,trade_number:Number(number)||1,direction,entry:Number(entry),stop_loss:Number(sl),take_profit:Number(tp),outcome,pips:Number(pips),session:session||null,strategy:strategy||null,notes:notes||null,image_url:null,image_path:null},file); setEntry('');setSl('');setTp('');setPips('');setNotes('');setFile(null);}finally{setBusy(false)}};
  return <form className="form" onSubmit={submit}>
    <div className="row"><div className="field"><label>Date</label><input type="date" value={date} onChange={e=>setDate(e.target.value)} required/></div><div className="field"><label>Instrument</label><input value={instrument} onChange={e=>setInstrument(e.target.value.toUpperCase())}/></div><div className="field"><label>Trade #</label><input type="number" min="1" value={number} onChange={e=>setNumber(e.target.value)}/></div></div>
    <div className="field"><label>Direction</label><div className="radio-row">{(['BUY','SELL'] as Direction[]).map(v=><button type="button" key={v} className={`radio ${direction===v?'active':''}`} onClick={()=>setDirection(v)}>{v}</button>)}</div></div>
    <div className="row"><div className="field"><label>Entry</label><input type="number" step="0.01" value={entry} onChange={e=>setEntry(e.target.value)} required/></div><div className="field"><label>Stop loss</label><input type="number" step="0.01" value={sl} onChange={e=>setSl(e.target.value)} required/></div><div className="field"><label>Take profit</label><input type="number" step="0.01" value={tp} onChange={e=>setTp(e.target.value)} required/></div></div>
    <div className="row"><div className="field"><label>Outcome</label><select value={outcome} onChange={e=>setOutcome(e.target.value as Outcome)}><option value="full_tp">Full TP</option><option value="break_even">Break-even</option><option value="stop_loss">Stop loss</option><option value="manual_close">Manual close</option></select></div><div className="field"><label>Recorded pips</label><input type="number" step="0.01" value={pips} onChange={e=>setPips(e.target.value)} required/></div><div className="field"><label>Session</label><input value={session} onChange={e=>setSession(e.target.value)}/></div></div>
    <div className="field"><label>Strategy</label><input value={strategy} onChange={e=>setStrategy(e.target.value)} placeholder="Optional"/></div>
    <div className="field"><label>Chart image</label><div className="filebox">Drop/select the TradingView screenshot<input type="file" accept="image/png,image/jpeg,image/webp" onChange={e=>setFile(e.target.files?.[0]??null)}/></div></div>
    <div className="field"><label>Notes</label><textarea value={notes} onChange={e=>setNotes(e.target.value)} placeholder="What happened? Why did you take it?"/></div>
    <button className="btn primary" disabled={busy}>{busy?'Saving…':'Save trade'}</button>
  </form>;
}
