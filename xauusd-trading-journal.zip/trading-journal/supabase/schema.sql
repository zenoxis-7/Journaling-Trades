create extension if not exists pgcrypto;

create table if not exists public.trades (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  trade_date date not null,
  instrument text not null default 'XAUUSD',
  trade_number integer not null default 1,
  direction text not null check (direction in ('BUY','SELL')),
  entry numeric(12,2) not null,
  stop_loss numeric(12,2) not null,
  take_profit numeric(12,2) not null,
  outcome text not null check (outcome in ('full_tp','break_even','stop_loss','manual_close')),
  pips numeric(12,2) not null default 0,
  session text,
  strategy text,
  notes text,
  image_url text,
  image_path text,
  created_at timestamptz not null default now()
);

create index if not exists trades_user_date_idx on public.trades(user_id, trade_date desc);

alter table public.trades enable row level security;

drop policy if exists "Users can read own trades" on public.trades;
drop policy if exists "Users can insert own trades" on public.trades;
drop policy if exists "Users can update own trades" on public.trades;
drop policy if exists "Users can delete own trades" on public.trades;

create policy "Users can read own trades" on public.trades for select using (auth.uid() = user_id);
create policy "Users can insert own trades" on public.trades for insert with check (auth.uid() = user_id);
create policy "Users can update own trades" on public.trades for update using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users can delete own trades" on public.trades for delete using (auth.uid() = user_id);

insert into storage.buckets (id, name, public) values ('trade-charts', 'trade-charts', true) on conflict (id) do nothing;

create policy "Trade charts are public to read" on storage.objects for select using (bucket_id = 'trade-charts');
create policy "Users can upload trade charts" on storage.objects for insert to authenticated with check (bucket_id = 'trade-charts' and (storage.foldername(name))[1] = auth.uid()::text);
create policy "Users can update own trade charts" on storage.objects for update to authenticated using (bucket_id = 'trade-charts' and owner_id = auth.uid()::text);
create policy "Users can delete own trade charts" on storage.objects for delete to authenticated using (bucket_id = 'trade-charts' and owner_id = auth.uid()::text);
