import './globals.css';
import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'XAUUSD · Trade Journal',
  description: 'Minimal trading journal for XAUUSD.',
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="en"><body>{children}</body></html>;
}
