import Dashboard from '@/components/Dashboard';
import { createClient } from '@/lib/supabase/server';
import { redirect } from 'next/navigation';

export const dynamic = 'force-dynamic';

export default async function Home(){
  if(process.env.NEXT_PUBLIC_SUPABASE_URL && process.env.NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY){
    const supabase=await createClient(); const {data:{claims}}=await supabase.auth.getClaims(); if(!claims) redirect('/auth/login');
  }
  return <Dashboard/>;
}
