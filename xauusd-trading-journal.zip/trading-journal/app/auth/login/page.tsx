'use client';
import { useState } from 'react';
import { createClient } from '@/lib/supabase/client';

export default function Login(){
 const [email,setEmail]=useState('');const [password,setPassword]=useState('');const [mode,setMode]=useState<'login'|'signup'>('login');const [msg,setMsg]=useState('');const [busy,setBusy]=useState(false);
 const submit=async(e:React.FormEvent)=>{e.preventDefault();setBusy(true);setMsg('');const supabase=createClient();const res=mode==='login'?await supabase.auth.signInWithPassword({email,password}):await supabase.auth.signUp({email,password,options:{emailRedirectTo:`${location.origin}/auth/confirm`}});setBusy(false);if(res.error){setMsg(res.error.message);return}if(mode==='signup'){setMsg('Account created. Check your email if confirmation is enabled.')}else location.href='/';};
 return <main className="auth"><div className="auth-card"><a className="back" href="/">← XAUUSD Journal</a><h1>{mode==='login'?'Sign in':'Create account'}</h1><p>Your private trading journal.</p>{msg&&<div className={`notice ${msg.includes('created')?'success':'error'}`}>{msg}</div>}<form className="form" onSubmit={submit}><div className="field"><label>Email</label><input type="email" value={email} onChange={e=>setEmail(e.target.value)} required/></div><div className="field"><label>Password</label><input type="password" minLength={6} value={password} onChange={e=>setPassword(e.target.value)} required/></div><button className="btn primary" disabled={busy}>{busy?'Working…':mode==='login'?'Sign in':'Create account'}</button></form><button className="btn" style={{width:'100%',marginTop:10}} onClick={()=>setMode(mode==='login'?'signup':'login')}>{mode==='login'?'Create an account':'Back to sign in'}</button></div></main>
}
